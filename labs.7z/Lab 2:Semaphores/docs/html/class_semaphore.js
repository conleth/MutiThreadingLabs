var class_semaphore =
[
    [ "Semaphore", "class_semaphore.html#a0d9290d316636875ca85d1d78950a817", null ],
    [ "Signal", "class_semaphore.html#a86f92f738b4486439b296d8e235895f2", null ],
    [ "Wait", "class_semaphore.html#a72aabebf026e3a8b1f3e4d0fa8ee1eda", null ],
    [ "Wait", "class_semaphore.html#a7f700173ae86ae623684109066e07656", null ]
];