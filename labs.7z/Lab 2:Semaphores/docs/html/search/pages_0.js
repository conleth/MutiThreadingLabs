var searchData=
[
  ['simple_20demo_20of_20how_20a_20samephore_20works',['simple demo of how a samephore works',['../index.html',1,'']]]
];
