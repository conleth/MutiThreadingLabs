var files =
[
    [ "Event.cpp", "_event_8cpp.html", null ],
    [ "Event.h", "_event_8h.html", [
      [ "Event", "class_event.html", "class_event" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "SafeBuffer.cpp", "_safe_buffer_8cpp.html", null ],
    [ "SafeBuffer.h", "_safe_buffer_8h.html", [
      [ "SafeBuffer", "class_safe_buffer.html", "class_safe_buffer" ]
    ] ],
    [ "Semaphore.cpp", "_semaphore_8cpp.html", null ],
    [ "Semaphore.h", "_semaphore_8h.html", [
      [ "Semaphore", "class_semaphore.html", "class_semaphore" ]
    ] ]
];