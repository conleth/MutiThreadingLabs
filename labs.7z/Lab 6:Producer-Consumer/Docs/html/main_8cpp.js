var main_8cpp =
[
    [ "consumer", "main_8cpp.html#a1b03e33da2f1c1d5d8bd8217e2f47a86", null ],
    [ "main", "main_8cpp.html#a568b3afc214ba30be5bf526d6b27b611", null ],
    [ "producer", "main_8cpp.html#a04627ad98145e680413663622c951db4", null ],
    [ "size", "main_8cpp.html#aab938108caad0d0e47d6885b5ba2d23a", null ]
];