var class_safe_buffer =
[
    [ "SafeBuffer", "class_safe_buffer.html#af835d8d08c4dcd3326f21ae2e9988699", null ],
    [ "get", "class_safe_buffer.html#a883f95ba075a1c0505be645c1d8ae4c0", null ],
    [ "put", "class_safe_buffer.html#a851df5cf7679efec7e27ec99842b7177", null ]
];