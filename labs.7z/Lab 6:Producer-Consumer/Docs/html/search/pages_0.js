var searchData=
[
  ['simple_20demo_20of_20how_20a_20producer_20consumer_20works',['simple demo of how a producer consumer works',['../index.html',1,'']]]
];
