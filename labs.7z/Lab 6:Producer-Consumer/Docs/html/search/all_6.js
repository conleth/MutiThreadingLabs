var searchData=
[
  ['simple_20demo_20of_20how_20a_20producer_20consumer_20works',['simple demo of how a producer consumer works',['../index.html',1,'']]],
  ['safebuffer',['SafeBuffer',['../class_safe_buffer.html',1,'SafeBuffer'],['../class_safe_buffer.html#af835d8d08c4dcd3326f21ae2e9988699',1,'SafeBuffer::SafeBuffer()']]],
  ['safebuffer_2ecpp',['SafeBuffer.cpp',['../_safe_buffer_8cpp.html',1,'']]],
  ['safebuffer_2eh',['SafeBuffer.h',['../_safe_buffer_8h.html',1,'']]],
  ['semaphore',['Semaphore',['../class_semaphore.html',1,'Semaphore'],['../class_semaphore.html#a0d9290d316636875ca85d1d78950a817',1,'Semaphore::Semaphore()']]],
  ['semaphore_2ecpp',['Semaphore.cpp',['../_semaphore_8cpp.html',1,'']]],
  ['semaphore_2eh',['Semaphore.h',['../_semaphore_8h.html',1,'']]],
  ['signal',['Signal',['../class_semaphore.html#a86f92f738b4486439b296d8e235895f2',1,'Semaphore']]],
  ['size',['size',['../main_8cpp.html#aab938108caad0d0e47d6885b5ba2d23a',1,'main.cpp']]]
];
