#pragma Once
class Event{
public:
	Event createEvent(int i);
	char consume();
	char randomChar;
	Event(int i);
};
