var searchData=
[
  ['updatetask',['updateTask',['../main_8cpp.html#a3c9683d6a27ab2759968c0378236e661',1,'main.cpp']]]
];
