var files =
[
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Semaphore.cpp", "_semaphore_8cpp.html", null ],
    [ "Semaphore.h", "_semaphore_8h.html", [
      [ "Semaphore", "class_semaphore.html", "class_semaphore" ]
    ] ]
];